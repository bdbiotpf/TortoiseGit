package testWS;

public class TT {

	public static void main(String[] args) {
		System.out.println("TEST OK");

	}

}
