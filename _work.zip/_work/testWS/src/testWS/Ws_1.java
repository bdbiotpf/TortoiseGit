package testWS;

import java.net.URI;

import javax.websocket.ClientEndpoint;
import javax.websocket.ContainerProvider;
import javax.websocket.OnMessage;
import javax.websocket.Session;
import javax.websocket.WebSocketContainer;

@ClientEndpoint
public class Ws_1 {
	@OnMessage
	public void onTextMessage(String msg, Session session) {
		System.out.println("onTextMessage: " + msg);
	}

	public static void main(String[] args) throws Exception {
		String url = "ws://ws2kafka.54.238.174.68.xip.io/Topic_from_java";
		WebSocketContainer container = ContainerProvider.getWebSocketContainer();
		Class<?> clazz = Ws_1.class;
		try { //サーバに接続
			Session session = container.connectToServer(clazz, URI.create(url)); //サーバに接続
			session.getBasicRemote().sendText("Hello1"); //文字列を送信
			session.getBasicRemote().sendText("Hello2"); //文字列を送信
			session.getBasicRemote().sendText("Hello3"); //文字列を送信
			Thread.sleep(3000L); //すぐ切断しないよう、暫定的に3秒待つ
			session.close();
		}
		finally {

		}
	}
}