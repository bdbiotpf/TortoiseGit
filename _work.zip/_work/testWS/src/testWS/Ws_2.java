package testWS;

import java.net.URI;

import javax.websocket.ClientEndpoint;
import javax.websocket.CloseReason;
import javax.websocket.ContainerProvider;
import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.WebSocketContainer;

@ClientEndpoint
public class Ws_2 {
	static boolean connected = false;

	public static void main(String[] args) throws Exception {
		String url = "ws://ws2kafka.54.238.174.68.xip.io/Topic_from_java2";
		connect(url);
	}

	@OnError
	public void onError(Session session, Throwable cause) {
		// エラー
		System.out.println("Error : " + session.getId() + ", " + cause.getMessage());
	}

	@OnMessage
	public void onMessage(String msg, Session session) {
		// 文字列を受け取る
		System.out.println("get onMessage: " + msg);
	}

	@OnClose
	public void onClose(Session session, CloseReason closeReason) {
		// 接続が閉じられた
		System.out.println("get closed");
		connected = false;
	}

	@OnOpen
	public void onOpen(Session session) {
		// 接続した
		System.out.println("get opened");
	}

	public static void connect(String url) {

		System.out.println("connect Start");

		WebSocketContainer container = ContainerProvider.getWebSocketContainer();
		Class<?> c = Ws_2.class;

		// 接続
		try {
			System.out.println("session Start");
			Session session = container.connectToServer(c, URI.create(url));
			connected = true;

			// while (connected) {
			// 接続中
			// 文字列を送る
			session.getBasicRemote().sendText("message1");		System.out.println("send : message1");
			session.getBasicRemote().sendText("message2");		System.out.println("send : message2");
			session.getBasicRemote().sendText("message3");		System.out.println("send : message3");
			Thread.sleep(3000L); // すぐ切断しないよう、暫定的に3秒待つ
			session.close();
			// }
		} catch (Exception e) {
			System.err.println(e);
		}
	}
}